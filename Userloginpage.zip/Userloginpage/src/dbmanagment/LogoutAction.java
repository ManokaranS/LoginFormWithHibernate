package dbmanagment;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LogoutAction extends Action{

	@Override
	public String execute(HttpServletRequest request,HttpServletResponse response) {
		HttpSession session=request.getSession();
		String uname=session.getAttribute("username").toString();
		HiberAction h=new HiberAction();
				
		if(h.checkuser(uname))
		{
			h.changestatus(uname,0);
			System.out.println("Status change success logout success");
			session.invalidate();
			return "Logout.success";
		}
		else
		{
			System.out.println("Logout Failed");
			return "Logout.failed";
		}
		
		
	}
}
