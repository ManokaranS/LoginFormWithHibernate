package dbmanagment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;

import JdbcOperation.JDBCUtility;

public class LoginAction extends Action{
	Session session1=SessionUtility.GetSessionConnection();
	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		String uname=request.getParameter("username");
		String upass=request.getParameter("password");
		//Connection con = JDBCUtility.GetConnection();
		HttpSession session=request.getSession();
		HiberAction h=new HiberAction();
		//PreparedStatement pre;
		try{
			//String sql="select * from user where username=? and password=?";
			//Query query=session1.createQuery(sql);
		//	query.setString(1, uname);
		//	query.setString(2, upass);
		//	query.executeUpdate();
			if (h.checkuser(uname,upass)) {	
				
				if(h.checkstatus(uname)){
					h.changestatus(uname,1);
					session.setAttribute("username",uname);
					return "Login.success";	
				}
				else
				{  
					System.out.println("Login Already Login.AlreadyLogin");
					session.setAttribute("username",uname);
					return "Login.AlreadyLogin";
				}
				
			
		}else {
			return "Login.failed";
			}
	}catch (Exception e) {
		SessionUtility.closeSession(e);

		System.err.println("Error Occured :" + e);
	}
	return "Login.failed";

}
}