package dbmanagment;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import JdbcOperation.JDBCUtility;

public class RegisterAction extends Action{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		String uname=request.getParameter("username");
		String upass=request.getParameter("password");
		HiberAction h=new HiberAction();
		//Connection con = JDBCUtility.GetConnection();
		try {
			
			if(!h.checkuser(uname, upass))
			{
			//PreparedStatement prep = con.prepareStatement("INSERT INTO user(username,password,status) VALUES(?,?,?)");
			//prep.setString(1,uname);
			//prep.setString(2,upass);
			//prep.setInt(3, 0);
			if (h.Register(uname, upass, 0)) {
				SessionUtility.closeSession(null);
				return "Register.success";
			} else {
				System.out.println("Registration Failed");
				return "Register.failed";
			}
			}
			else
			{
				System.out.println("User Alrady Exist");
				return "Register.exist";
			}
		} catch (Exception e) {
			SessionUtility.closeSession(e);
		}
		return "Register.failed";
	}
}

